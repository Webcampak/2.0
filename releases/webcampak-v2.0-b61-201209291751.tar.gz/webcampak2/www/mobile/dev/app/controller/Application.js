/*
Copyright 2010-2012 Infracom & Eurotechnia (support@webcampak.com)
This file is part of the Webcampak project.
Webcampak is free software: you can redistribute it and/or modify it 
under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, 
or (at your option) any later version.

Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Webcampak. 
If not, see http://www.gnu.org/licenses/.
*/
console.log('Log: Load: WebcampakMobile.controller.Application');
Ext.define('WebcampakMobile.controller.Application', {
	extend: 'Ext.app.Controller',

	config: {

		stores: [
			'ViewPictures',
			'SendEmail',	
			'InsertComment'						
		],    	
		models: [
			'ViewPicture',
			'SendEmail',
			'InsertComment'							
		],
		
		refs: {
			main: 				'mainview',
			
			previousButton: 	'#previousButton', 
			nextButton: 		'#nextButton',   
			  
			datePicker: 		'#datePicker',
			datePickerDone: 	'#datePickerDone',	
			displayImage: 		'#displayImage',
			sourceDatePicker: 'source-datepicker',				
			
			emailButton: 		'#emailButton',	
			emailSendButton: 	'#emailSendButton',
			emailPrepare: 		'email-prepare',
			
			commentButton: 		'#commentButton',						
			saveCommentButton: 	'#saveCommentButton',
			commentInsert: 		'comment-insert',	

			creditToolbar: 		'#creditToolbar',	
																			       			           			       			           
			sources: 			'sources',
			pictureView: 		'source-show'
		},
	
		control: {
			viewport: 				{orientationchange: 	'onOrientationChange'	},      	
			displayImage: 			{load: 					'onImageLoaded'			},      				
			sources: 				{itemtap: 				'onSourceSelect' 			},
			previousButton: 		{tap: 					'previousPicture'			},            
			nextButton: 			{tap: 					'nextPicture'				},
			            
			emailButton: 			{tap: 					'onEmailPrepare'			},
			emailSendButton: 		{tap: 					'onEmailSend'				},	
			
			commentButton: 		{tap: 					'onCommentInsert'			},				
			saveCommentButton: 	{tap: 					'onCommentSubmit'			},		

			datePicker: 			{tap: 					'onDatePicker'				},
			datePickerDone: 		{tap: 					'onDatePickerDone'	},
					
			main: 					{push: 'onMainPush',	pop: 'onMainPop'			}
		}
	},

	showCreditToolbar: function() {
		console.log('Log: Controller->Application - showCreditToolbar() function');    	    	    	    	    	    	    	
		var creditToolbar = this.getCreditToolbar();
		if (!creditToolbar.isHidden()) {return;}
		this.hideCreditToolbar();
		creditToolbar.show();
	},

	hideCreditToolbar: function() {
		console.log('Log: Controller->Application - hideCreditToolbar() function');    	    	    	    	    	    	    	    	
		var creditToolbar = this.getCreditToolbar();
		if (creditToolbar.isHidden()) {return;}
		creditToolbar.hide();
	},

	onCommentSubmit: function() {
		console.log('Log: Controller->Application - onCommentSubmit() function');    	    	    	    	    	    	
		var commentContent = this.getCommentInsert().saveRecord();
		this.hideSaveCommentButton();

		viewPicturesStore = Ext.getStore('ViewPictures');			
		viewPicturesStore.load();	

		this.hideSaveCommentButton();

		this.getMain().pop();						
	},

	onCommentInsert: function() {
		console.log('Log: Controller->Application - onCommentInsert() function');    	   
		Ext.Viewport.setMasked(false);		 	    	    	
		if (!this.commentInsert) {this.commentInsert = Ext.create('WebcampakMobile.view.source.InsertComment');}

		viewPicturesStore = Ext.getStore('ViewPictures');	
		displayedPicture = viewPicturesStore.last();

		Ext.getStore('InsertComment').getProxy().setExtraParam('picture', displayedPicture.data.picturetime);		

		insertCommentStore = Ext.getStore('InsertComment');
		commentTmp = insertCommentStore.last();	
		commentTmp.data.commentcontent = displayedPicture.data.picturecomment;		
		commentTmp.data.picturetime = displayedPicture.data.picturetime + '.jpg';

		// Bind the record onto the edit contact view
		this.commentInsert.updateRecord(commentTmp);

		this.hideDatePicker(); 		
		this.showSaveCommentButton();

		this.getMain().push(this.commentInsert);
	},

	showSaveCommentButton: function() {
		console.log('Log: Controller->Application - showSaveCommentButton() function');    	    	    	    	    	    	    	    	    	
		var saveCommentButton = this.getSaveCommentButton();
		if (!saveCommentButton.isHidden()) {return;}
		saveCommentButton.show();
	},

	hideSaveCommentButton: function() {
		console.log('Log: Controller->Application - hideSaveCommentButton() function');    	    	    	    	    	    	    	    	    	    	
		var saveCommentButton = this.getSaveCommentButton();
		if (saveCommentButton.isHidden()) {return;}
		saveCommentButton.hide();
    },

	onEmailPrepare: function() {
		console.log('Log: Controller->Application - onEmailPrepare() function');   
		Ext.Viewport.setMasked(false);		 	    	    	    	
		if (!this.emailPrepare) { this.emailPrepare = Ext.create('WebcampakMobile.view.source.EmailPrepare');}
		
		viewPicturesStore = Ext.getStore('ViewPictures');	
		displayedPicture = viewPicturesStore.last();
		Ext.getStore('SendEmail').getProxy().setExtraParam('picture', displayedPicture.data.picturetime);		

		sendEmailStore = Ext.getStore('SendEmail');
		emailTmp = sendEmailStore.last();	
		emailTmp.data.emailpicture = displayedPicture.data.picturetime + '.jpg';		

		// Bind the record onto the edit contact view
		this.emailPrepare.updateRecord(emailTmp);

		this.hideDatePicker(); 		
		this.showEmailSendButton();

		this.getMain().push(this.emailPrepare);
	},

	onEmailSend: function() {
		console.log('Log: Controller->Application - onEmailSend() function');    	    	    	    	    	    	
		var emailContent = this.getEmailPrepare().saveRecord();
		this.hideEmailSendButton();		
		this.getMain().pop();		
	},

	showEmailSendButton: function() {
		console.log('Log: Controller->Application - showEmailSendButton() function');    	    	    	    	    	    	    	    	    	
		var emailSendButton = this.getEmailSendButton();
		if (!emailSendButton.isHidden()) {return;}
		emailSendButton.show();
	},

	hideEmailSendButton: function() {
		console.log('Log: Controller->Application - hideEmailSendButton() function');    	    	    	    	    	    	    	    	    	    	
		var emailSendButton = this.getEmailSendButton();
		if (emailSendButton.isHidden()) {return;}
		emailSendButton.hide();
    },

	onImageLoaded: function() {
		console.log('Log: Controller->Application - onImageLoaded() function');	
		Ext.Viewport.setMasked(false);
	},

	onDatePicker: function() {
		console.log('Log: Controller->Application - onDatePicker() function');
		if (!this.sourceDatePicker) { this.sourceDatePicker = Ext.create('WebcampakMobile.view.source.DatePicker');}	

		//We get picture timestampe in order to display the picker on the last selected picture
		viewPicturesStore = Ext.getStore('ViewPictures');	
		displayedPicture = viewPicturesStore.last();		
		var currentPictureTime = displayedPicture.data.picturetime + "";				
		var currentPictureMonth = currentPictureTime.substring(4, 6) - 1; 		
		var currentPictureDate = new Date(currentPictureTime.substring(0, 4), currentPictureMonth, currentPictureTime.substring(6, 8), currentPictureTime.substring(8, 10), currentPictureTime.substring(10, 12), currentPictureTime.substring(12, 14), 0);				

		console.log(this.sourceDatePicker);
		Ext.Viewport.add(this.sourceDatePicker);
		this.sourceDatePicker.setValueAnimated(currentPictureDate);
		this.sourceDatePicker.show();			
	},	

	onDatePickerDone: function() {
		console.log('Log: Controller->Application - onDatePickerDone() function');
		selectedTimestamp = new Date(this.sourceDatePicker.getValue()).getTime();	
		console.log('Log: Controller->Application->onDatePicker - handler - selected timestamp: ' + dateFormat(selectedTimestamp, 'yyyyddmmHHMMss'));			
		viewPicturesStore = Ext.getStore('ViewPictures');
		Ext.getStore('ViewPictures').getProxy().setExtraParam('currentdate', dateFormat(selectedTimestamp, 'yyyymmddHHMMss'));	
		this.sourceDatePicker.hide();	
		viewPicturesStore.on('load',this.loadPicture,this,{single:true});
		viewPicturesStore.load();																	
	},	

	onReloadPictureStore: function() {
		console.log('Log: Controller->Application - onReloadPictureStore() function');
		Ext.getCmp('datePickerDone').destroy();	
		console.log('Log: Controller->Application - onReloadPictureStore() - datePickerDone destroyed');				

		//picker.destroy();										
		viewPicturesStore = Ext.getStore('ViewPictures');			
		viewPicturesStore.on('load',this.loadPicture,this,{single:true});
		viewPicturesStore.load();	
	},

	onSourceSelect: function(list, index, node, record) {
		console.log('Log: Controller->Application - onSourceSelect() function');   
	
		// We don t want to show credit toolbar at this stage (only on main screen)
		this.hideCreditToolbar(); 
		viewPicturesStore = Ext.getStore('ViewPictures');

		Ext.getStore('ViewPictures').getProxy().setExtraParam('sourceid', record.data.sourceid);
		Ext.getStore('ViewPictures').getProxy().setExtraParam('currentdate', record.data.latestpicturedate);		
		Ext.getStore('SendEmail').getProxy().setExtraParam('sourceid', record.data.sourceid);
		Ext.getStore('InsertComment').getProxy().setExtraParam('sourceid', record.data.sourceid);				

		viewPicturesStore.on('load',this.loadPicture,this,{single:true});
		viewPicturesStore.load();	

		Ext.Viewport.setMasked(false);		
		
    },
    
	onOrientationChange: function() {
		console.log('Log: Controller->Application - onOrientationChange() function');	
		if (typeof this.getMain().getItems().items[2] != 'undefined') {
			if (this.getMain().getItems().items[2].id == "source-show-display") {
				this.loadPicture(); 	    	   
			} 		
		} else {
		console.log('Log: Controller->Application - onOrientationChange() - No action taken, currently not in picture view mode');			
		}
	
	},	
	    
	loadPicture: function() {
		console.log('Log: Controller->Application - loadPicture() function');   

		viewPicturesStore = Ext.getStore('ViewPictures');	
		displayPicture = viewPicturesStore.last();
		
		if (!this.showSource) {this.showSource = Ext.create('WebcampakMobile.view.source.Show');}
		this.showSource.updateRecord(displayPicture);
		this.getMain().push(this.showSource);	
		this.showDatePicker();
	},

	previousPicture: function() {
		console.log('Log: Controller->Application - previousPicture() function');   
		viewPicturesStore = Ext.getStore('ViewPictures');		 
		if (viewPicturesStore.getCount() > 0) {
			currentPictureValue = viewPicturesStore.last();
			var selectedpicture = currentPictureValue.getData()['pictureprevious'] + "";
			Ext.getStore('ViewPictures').getProxy().setExtraParam('currentdate', selectedpicture);			
			viewPicturesStore.on('load',this.loadPicture,this,{single:true});
			viewPicturesStore.load();	
		}		
	},

	nextPicture: function() {
		console.log('Log: Controller->Application - nextPicture() function'); 	
		viewPicturesStore = Ext.getStore('ViewPictures');		 
		if (viewPicturesStore.getCount() > 0) {
			currentPictureValue = viewPicturesStore.last();
			var selectedpicture = currentPictureValue.getData()['picturenext'] + "";
			Ext.getStore('ViewPictures').getProxy().setExtraParam('currentdate', selectedpicture);			
			viewPicturesStore.on('load',this.loadPicture,this,{single:true});
			viewPicturesStore.load();	
		}		   	
	},

    showDatePicker: function() {
		console.log('Log: Controller->Application - showDatePicker() function');    	    	    	    	    	    	    	
        var dateButton = this.getDatePicker();
        if (!dateButton.isHidden()) {
            return;
        }
        this.hideDatePicker();
        dateButton.show();
    },

    hideDatePicker: function() {
		console.log('Log: Controller->Application - hideDatePicker() function');    	    	    	    	    	    	    	    	
        var dateButton = this.getDatePicker();
        if (dateButton.isHidden()) {
            return;
        }
        dateButton.hide();
    },


    onMainPush: function(view, item) {
		console.log('Log: Controller->Application - onMainPush() function');    	
    },

    onMainPop: function(view, item) {
		console.log('Log: Controller->Application - onMainPop() function');  
		this.hideEmailSendButton(); 
		this.hideSaveCommentButton();            				         
		this.hideDatePicker();    	    	
    } 
});
