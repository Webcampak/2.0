/*
Copyright 2010-2012 Infracom & Eurotechnia (support@webcampak.com)
This file is part of the Webcampak project.
Webcampak is free software: you can redistribute it and/or modify it 
under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, 
or (at your option) any later version.

Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Webcampak. 
If not, see http://www.gnu.org/licenses/.
*/
console.log('Log: Load: WebcampakMobile.view.Main');
Ext.define('WebcampakMobile.view.Main', {
	extend: 'Ext.navigation.View',
	xtype: 'mainview',

	requires: [
		'WebcampakMobile.view.Sources',
		'WebcampakMobile.view.source.EmailPrepare',
		'WebcampakMobile.view.source.DatePicker',		
		'WebcampakMobile.view.source.InsertComment',
		'WebcampakMobile.view.source.Show'
	],

	config: {
		autoDestroy: false,

		navigationBar: {
			ui: 'sencha',
			items: [{
				text : i18n.gettext('Date'),
				ui : 'action',
				id: 'datePicker',
				xtype : 'button',
				align: 'right',
				hidden: true,
				hideAnimation: Ext.os.is.Android ? false : {type: 'fadeOut',	duration: 200},
				showAnimation: Ext.os.is.Android ? false : {type: 'fadeIn',		duration: 200}
			}, {
				xtype: 'button',
				id: 'saveCommentButton',
				ui: 'confirm',
				text: i18n.gettext('Save'),
				align: 'right',
				hidden: true,
				hideAnimation: Ext.os.is.Android ? false : {type: 'fadeOut',	duration: 200},
				showAnimation: Ext.os.is.Android ? false : {type: 'fadeIn',		duration: 200}				
			}, {
				xtype: 'button',
				id: 'emailSendButton',
				text: i18n.gettext('Send'),
				ui: 'confirm',
				align: 'right',
				hidden: true,
				hideAnimation: Ext.os.is.Android ? false : {type: 'fadeOut',	duration: 200},
				showAnimation: Ext.os.is.Android ? false : {type: 'fadeIn',		duration: 200}
			}]
		},
		items: [{ 
			xtype: 'sources' 
		}, {
			xtype : 'titlebar',
			id: 'creditToolbar',
			title: '<i>' + i18n.gettext('contact@webcampak.com') + '</i>',
			docked: 'bottom',
			items: [{ 
				align: 'right',
				itemId: 'flagfr',	
				xtype: 'button', 	
				iconCls: 'flag-fr',
				handler: function(){
					document.location.href = "index.html?lang=fr";         
				}				
			}, {
				align: 'left',				
				itemId: 'flagen',	
				xtype: 'button', 	
				href: 'index.html?lang=en', 
				hrefTarget: '_self', 
				iconCls: 'flag-en',
				handler: function(){
					document.location.href = "index.html?lang=en";         
				}						 												
			}]      
		}]
	}
});
