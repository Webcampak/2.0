/*
Copyright 2010-2012 Infracom & Eurotechnia (support@webcampak.com)
This file is part of the Webcampak project.
Webcampak is free software: you can redistribute it and/or modify it 
under the terms of the GNU General Public License as published by 
the Free Software Foundation, either version 3 of the License, 
or (at your option) any later version.

Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Webcampak. 
If not, see http://www.gnu.org/licenses/.
*/
console.log('Log: Load: WebcampakMobile.view.source.InsertComment');
Ext.define('WebcampakMobile.view.source.InsertComment', {
	extend: 'Ext.Container',
	xtype: 'comment-insert',




	config: {
		title: i18n.gettext('Insert or edit comment'),
		layout: 'fit',

		items: [{
			xtype: 'formpanel',
			items: [{
				xtype: 'fieldset',
				defaults: {
					labelWidth: '35%'
				},
				title: i18n.gettext('Picture'),
				items: [{
					xtype: 'textfield',
					name: 'picturetime',
					disabled: true
				}]
			},	{				
				xtype: 'fieldset',
				defaults: {
					labelWidth: '35%'
				},
				title: i18n.gettext('Comment'),
				items: [{
					xtype: 'textareafield',
					maxRows: 6,
					name: 'commentcontent'
				}]
			}]	
		}],
	
		listeners: {
			delegate: 'textfield',
			keyup: 'onKeyUp'
		},
		record: null
	},

    updateRecord: function(newRecord) {
        this.down('formpanel').setRecord(newRecord);
    },

    saveRecord: function() {
        var formPanel = this.down('formpanel'),
            record = formPanel.getRecord();

        formPanel.updateRecord(record);

        return record;
    },

    onKeyUp: function() {
        this.fireEvent('change', this);
    }
});
